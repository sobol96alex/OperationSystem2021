#include "u-lib.hh"

void process_main() {
    sys_exit(1);
}
