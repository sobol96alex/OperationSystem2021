CS 161 Problem Set 5 Collaboration
==================================

Collaborators
-------------
(Other students you worked with)

Citations
---------
(Other sources consulted)
